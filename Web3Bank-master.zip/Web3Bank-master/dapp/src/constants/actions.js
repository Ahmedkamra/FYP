const USER = {
    SITE_INIT: "site-init",
    CHAIN_INIT: "bc-init",
    CHAIN_UPDATE_ACCOUNT: "bc-update-account",
    LOGOUT: "logout",
}

module.exports = {
    USER,
}
